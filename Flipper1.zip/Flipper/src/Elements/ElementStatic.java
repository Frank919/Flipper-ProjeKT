package Elements;

public class ElementStatic extends ElementBasic{
    
}
