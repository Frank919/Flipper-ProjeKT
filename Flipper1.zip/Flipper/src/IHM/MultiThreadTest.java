package IHM;

public class MultiThreadTest {
    public static void main(String[] args) throws InterruptedException {
        while(true){
            Thread.sleep(100);
            System.out.println("1000000");
        }
        
    }
    
}
