import IHM.*;

public class App {
    public static void main(String[] args) throws Exception {
        //new GameRules();
        //new SelectionBall();
        new MainWindow(1);
        
        
    }
}

