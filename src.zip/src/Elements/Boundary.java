package Elements;

public class Boundary extends ElementStatic{
    public Boundary(){
        
    }
}
