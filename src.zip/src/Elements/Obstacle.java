package Elements;

public class Obstacle extends ElementStatic{
    public Obstacle(){
        
    }
}
