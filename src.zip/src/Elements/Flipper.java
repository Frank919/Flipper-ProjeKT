package Elements;

public class Flipper extends ElementKinetic{
    public Flipper(){
        
    }
}
