package Elements;

public class Space extends ElementBasic{
    public Space(int x, int y){
        super(x, y);
    }
}
